def send(text):
    print("正在发送短信%s" %text)